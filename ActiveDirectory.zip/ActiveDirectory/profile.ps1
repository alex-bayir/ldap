Import-Module "...\ActiveDirectory\Microsoft.ActiveDirectory.Management.resources.dll"
Import-Module "...\ActiveDirectory\Microsoft.ActiveDirectory.Management.dll"
Import-Module "...\ActiveDirectory\ActiveDirectory.psd1"